#!/bin/sh

while [ 1 ]
do
    ./eggminer
    sleep 0.1
done
